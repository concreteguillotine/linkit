import "@hotwired/turbo-rails";
